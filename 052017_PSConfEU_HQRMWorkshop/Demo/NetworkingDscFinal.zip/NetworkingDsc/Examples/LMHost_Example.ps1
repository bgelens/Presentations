﻿configuration Example
{
    Import-DscResource -ModuleName NetworkingDsc

    node localhost
    {
        LMHost Disable
        {
            IsSingleInstance = 'Yes'
            Enable = $false
        }
    }
}
