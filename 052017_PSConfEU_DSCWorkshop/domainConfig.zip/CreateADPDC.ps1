﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
        }

        Script DisableFirewall {
            GetScript = {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                }
            }

            SetScript = {
                Set-NetFirewallProfile -All -Enabled False -Verbose
            }

            TestScript = {
                $Status = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                $Status -eq $True
            }
        }
        
        WindowsFeature DNS { 
            Ensure = "Present" 
            Name = "DNS"
        }

        WindowsFeature ADDSInstall { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
            DependsOn = "[WindowsFeature]DNS"
        }  

        xADDomain FirstDS {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        Script RemoveDSCImplementation {
            GetScript = {
                return @{
                    TestScript = $TestScript
                    GetScript = $GetScript
                    SetScript = $SetScript
                }
            }
            SetScript = {
                $scriptblock = {
                    Start-Sleep -Seconds 30
                    Get-PSHostProcessInfo | 
                        Where-Object -FilterScript { $_.AppDomainName -eq 'DscPsPluginWkr_AppDomain'} |
                            Foreach-Object -Process { $_.ProcessId | Stop-Process -Force}
                    Clear-Content -Path "$env:windir\system32\Configuration\DSCEngineCache.mof"
                    Clear-Content -Path "$env:windir\system32\Configuration\DSCStatusHistory.mof"
                    Remove-Item -Path "$env:windir\System32\Configuration\ConfigurationStatus\*" -Force
                    Remove-Item -Path "$env:windir\System32\Configuration\*.mof" -Force
                    Remove-Item -Path "$env:windir\System32\Configuration\*.mof.checksum" -Force
                    @(
                        'Microsoft-Windows-DSC/Admin',
                        'Microsoft-Windows-DSC/Operational'
                    ) | ForEach-Object -Process {
                        [System.Diagnostics.Eventing.Reader.EventLogSession]::GlobalSession.ClearLog($_)
                    }
                    Remove-Item 'C:\Program Files\WindowsPowerShell\Modules\x*' -Recurse -Force
                    Restart-Computer -Force
                }
                start-process $pshome\powershell.exe -ArgumentList "-Command `"&{$($scriptblock.ToString())}`""
            }
            TestScript = {
                $false
            }
            DependsOn = '[xADDomain]FirstDS'
        }
   }
} 